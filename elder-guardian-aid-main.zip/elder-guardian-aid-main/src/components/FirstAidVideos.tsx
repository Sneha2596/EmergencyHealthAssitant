import { useState } from "react";
import { Play, ExternalLink, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";

const allVideos = [
  {
    id: 1,
    title: "CPR Basics",
    description: "Learn life-saving CPR technique",
    thumbnail: "https://img.youtube.com/vi/hizBdM1Ob68/maxresdefault.jpg",
    url: "https://www.youtube.com/watch?v=hizBdM1Ob68",
    duration: "4:32",
    keywords: ["cpr", "cardiopulmonary", "resuscitation", "heart", "chest", "compression"]
  },
  {
    id: 2,
    title: "Choking First Aid",
    description: "Heimlich maneuver for adults",
    thumbnail: "https://img.youtube.com/vi/PA9hpOnvtCk/maxresdefault.jpg",
    url: "https://www.youtube.com/watch?v=PA9hpOnvtCk",
    duration: "3:15",
    keywords: ["choking", "heimlich", "airway", "obstruction", "throat"]
  },
  {
    id: 3,
    title: "Bleeding Control",
    description: "Stop severe bleeding quickly",
    thumbnail: "https://img.youtube.com/vi/NxO5LvgqZe0/maxresdefault.jpg",
    url: "https://www.youtube.com/watch?v=NxO5LvgqZe0",
    duration: "5:20",
    keywords: ["bleeding", "blood", "wound", "cut", "hemorrhage", "bandage"]
  },
  {
    id: 4,
    title: "Heart Attack Signs",
    description: "Recognize and respond fast",
    thumbnail: "https://img.youtube.com/vi/gDwt7dD3awc/maxresdefault.jpg",
    url: "https://www.youtube.com/watch?v=gDwt7dD3awc",
    duration: "3:45",
    keywords: ["heart", "attack", "cardiac", "chest", "pain", "symptoms"]
  },
  {
    id: 5,
    title: "Burns Treatment",
    description: "Proper burn care steps",
    thumbnail: "https://img.youtube.com/vi/EaJmzB8YgS0/maxresdefault.jpg",
    url: "https://www.youtube.com/watch?v=EaJmzB8YgS0",
    duration: "4:10",
    keywords: ["burn", "burns", "fire", "scald", "heat", "skin"]
  },
  {
    id: 6,
    title: "Fracture First Aid",
    description: "Handle bone injuries safely",
    thumbnail: "https://img.youtube.com/vi/2v8vlXgGXwE/maxresdefault.jpg",
    url: "https://www.youtube.com/watch?v=2v8vlXgGXwE",
    duration: "4:55",
    keywords: ["fracture", "bone", "broken", "splint", "injury", "fall"]
  }
];

const FirstAidVideos = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const { t } = useLanguage();

  const handleVideoClick = (url: string) => {
    window.open(url, "_blank");
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setHasSearched(true);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  const filteredVideos = hasSearched
    ? allVideos.filter((video) => {
        const query = searchQuery.toLowerCase();
        return (
          video.title.toLowerCase().includes(query) ||
          video.description.toLowerCase().includes(query) ||
          video.keywords.some((keyword) => keyword.includes(query))
        );
      })
    : [];

  return (
    <Card className="border-2 border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-accessible-lg text-primary">
          <Play className="h-8 w-8" />
          {t("firstAidVideos")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search Bar */}
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder={t("searchFirstAid")}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={handleKeyPress}
            className="h-12 text-base"
          />
          <Button variant="medical" size="lg" onClick={handleSearch}>
            <Search className="h-5 w-5" />
            {t("search")}
          </Button>
        </div>

        {/* Initial State - No Search Yet */}
        {!hasSearched && (
          <div className="text-center py-12 bg-muted/30 rounded-2xl">
            <Play className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground text-lg">
              {t("searchForVideos")}
            </p>
          </div>
        )}

        {/* Search Results */}
        {hasSearched && filteredVideos.length === 0 && (
          <div className="text-center py-12 bg-muted/30 rounded-2xl">
            <p className="text-muted-foreground text-lg">
              {t("noVideosFound")}
            </p>
          </div>
        )}

        {hasSearched && filteredVideos.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredVideos.map((video) => (
              <button
                key={video.id}
                onClick={() => handleVideoClick(video.url)}
                className="group relative rounded-2xl overflow-hidden bg-muted card-hover text-left"
              >
                <div className="aspect-video relative">
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-foreground/40 group-hover:bg-foreground/30 transition-colors flex items-center justify-center">
                    <div className="bg-destructive rounded-full p-4 group-hover:scale-110 transition-transform">
                      <Play className="h-8 w-8 text-white fill-current" />
                    </div>
                  </div>
                  <span className="absolute bottom-2 right-2 bg-foreground/80 text-background px-2 py-1 rounded-lg text-sm font-medium">
                    {video.duration}
                  </span>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg text-foreground group-hover:text-primary transition-colors">
                    {video.title}
                  </h3>
                  <p className="text-muted-foreground text-base mt-1">
                    {video.description}
                  </p>
                  <div className="flex items-center gap-1 mt-2 text-primary text-sm">
                    <ExternalLink className="h-4 w-4" />
                    {t("watchOnYoutube")}
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FirstAidVideos;
