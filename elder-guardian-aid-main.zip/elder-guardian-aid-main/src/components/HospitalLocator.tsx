import { useState } from "react";
import { MapPin, Search, ExternalLink, Stethoscope } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const specialties = [
  { value: "general", label: "General Hospital" },
  { value: "cardiology", label: "Cardiologist (Heart Specialist)" },
  { value: "orthopedic", label: "Orthopedic (Bone & Joint)" },
  { value: "gynecologist", label: "Gynecologist (Women's Health)" },
  { value: "pediatric", label: "Pediatrician (Child Specialist)" },
  { value: "neurologist", label: "Neurologist (Brain & Nerve)" },
  { value: "dermatologist", label: "Dermatologist (Skin Specialist)" },
  { value: "ent", label: "ENT (Ear, Nose, Throat)" },
  { value: "ophthalmologist", label: "Ophthalmologist (Eye Specialist)" },
  { value: "dentist", label: "Dentist (Dental Care)" },
  { value: "gastroenterologist", label: "Gastroenterologist (Digestive System)" },
  { value: "urologist", label: "Urologist (Urinary System)" },
  { value: "psychiatrist", label: "Psychiatrist (Mental Health)" },
  { value: "oncologist", label: "Oncologist (Cancer Specialist)" },
  { value: "emergency", label: "Emergency Care/Trauma Center" }
];

const HospitalLocator = () => {
  const [location, setLocation] = useState("");
  const [specialty, setSpecialty] = useState("general");

  const handleFindHospitals = () => {
    const query = location.trim() || "nearby";
    const selectedSpecialty = specialties.find(s => s.value === specialty)?.label || "hospitals";
    const searchQuery = specialty === "general" 
      ? `hospitals near ${query}`
      : `${selectedSpecialty} near ${query}`;
    const mapsUrl = `https://www.google.com/maps/search/${encodeURIComponent(searchQuery)}`;
    window.open(mapsUrl, "_blank");
  };

  const handleUseCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const selectedSpecialty = specialties.find(s => s.value === specialty)?.label || "hospitals";
          const searchQuery = specialty === "general" 
            ? "hospitals"
            : selectedSpecialty;
          const mapsUrl = `https://www.google.com/maps/search/${encodeURIComponent(searchQuery)}/@${latitude},${longitude},14z`;
          window.open(mapsUrl, "_blank");
        },
        () => {
          alert("Unable to get your location. Please enter manually.");
        }
      );
    } else {
      alert("Geolocation is not supported by your browser.");
    }
  };

  return (
    <Card className="card-hover border-2 border-primary/20">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-3 text-accessible-lg text-primary">
          <MapPin className="h-8 w-8" />
          Find Nearby Hospitals
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col gap-3">
          <div className="space-y-2">
            <label className="text-sm font-medium flex items-center gap-2">
              <Stethoscope className="h-4 w-4 text-primary" />
              Select Doctor/Hospital Type
            </label>
            <Select value={specialty} onValueChange={setSpecialty}>
              <SelectTrigger className="h-12 text-base">
                <SelectValue placeholder="Choose specialty" />
              </SelectTrigger>
              <SelectContent>
                {specialties.map((spec) => (
                  <SelectItem key={spec.value} value={spec.value} className="text-base">
                    {spec.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <Input
            type="text"
            placeholder="Enter city, area, or pincode..."
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="h-12 text-base rounded-lg"
          />
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="medical"
              size="default"
              onClick={handleFindHospitals}
              className="text-sm"
            >
              <Search className="h-4 w-4" />
              Search
            </Button>
            <Button
              variant="outline"
              size="default"
              onClick={handleUseCurrentLocation}
              className="text-sm"
            >
              <MapPin className="h-4 w-4" />
              My Location
            </Button>
          </div>
        </div>
        <p className="text-muted-foreground text-center text-base">
          <ExternalLink className="inline h-4 w-4 mr-1" />
          Opens in Google Maps
        </p>
      </CardContent>
    </Card>
  );
};

export default HospitalLocator;
