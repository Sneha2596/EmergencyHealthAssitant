import { useState } from "react";
import { AlertTriangle, Shield, Phone, Bell, CheckCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

const FallDetection = () => {
  const [isEnabled, setIsEnabled] = useState(true);
  const [alertTriggered, setAlertTriggered] = useState(false);
  const [countdown, setCountdown] = useState(30);

  const handleTestAlert = () => {
    setAlertTriggered(true);
    setCountdown(30);
    
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          // In real app, this would send emergency alert
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleCancelAlert = () => {
    setAlertTriggered(false);
    setCountdown(30);
  };

  const handleConfirmEmergency = () => {
    window.location.href = "tel:108";
  };

  return (
    <Card className={`border-2 ${alertTriggered ? "border-emergency fall-alert" : "border-primary/20"}`}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-accessible-lg text-primary">
            <Shield className="h-8 w-8" />
            Fall Detection
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">
              {isEnabled ? "Active" : "Inactive"}
            </span>
            <Switch
              checked={isEnabled}
              onCheckedChange={setIsEnabled}
              className="data-[state=checked]:bg-success"
            />
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {!alertTriggered ? (
          <>
            <div className={`text-center py-6 rounded-2xl ${isEnabled ? "bg-success/10" : "bg-muted"}`}>
              <CheckCircle className={`h-16 w-16 mx-auto mb-3 ${isEnabled ? "text-success" : "text-muted-foreground"}`} />
              <p className="text-accessible-sm font-semibold">
                {isEnabled ? "Fall Detection Active" : "Fall Detection Disabled"}
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                {isEnabled
                  ? "Your device is monitoring for sudden falls or crashes"
                  : "Enable to automatically detect falls and send alerts"}
              </p>
            </div>

            {isEnabled && (
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
                  <Bell className="h-6 w-6 text-primary" />
                  <div>
                    <p className="font-medium">Auto-Alert</p>
                    <p className="text-sm text-muted-foreground">
                      30 second countdown before calling emergency
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
                  <Phone className="h-6 w-6 text-primary" />
                  <div>
                    <p className="font-medium">Emergency Contacts</p>
                    <p className="text-sm text-muted-foreground">
                      Family members will be notified
                    </p>
                  </div>
                </div>
              </div>
            )}

            <Button
              variant="outline"
              size="lg"
              onClick={handleTestAlert}
              className="w-full"
              disabled={!isEnabled}
            >
              <AlertTriangle className="h-6 w-6" />
              Test Fall Alert
            </Button>
          </>
        ) : (
          <div className="space-y-6 text-center">
            {/* Alert Warning */}
            <div className="bg-emergency/20 rounded-2xl p-6">
              <AlertTriangle className="h-16 w-16 mx-auto text-emergency mb-3 fall-alert" />
              <h3 className="text-accessible-lg font-bold text-emergency">
                Fall Detected!
              </h3>
              <p className="text-muted-foreground mt-2">
                Are you okay? Emergency services will be called in:
              </p>
            </div>

            {/* Countdown */}
            <div className="relative w-32 h-32 mx-auto">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="64"
                  cy="64"
                  r="56"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  className="text-muted"
                />
                <circle
                  cx="64"
                  cy="64"
                  r="56"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray={352}
                  strokeDashoffset={352 - (352 * countdown) / 30}
                  className="text-emergency transition-all duration-1000"
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-accessible-2xl font-bold text-emergency">
                {countdown}
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-3">
              <Button
                variant="success"
                size="xl"
                onClick={handleCancelAlert}
                className="w-full bg-success hover:bg-success/90"
              >
                <CheckCircle className="h-8 w-8" />
                I'm Okay - Cancel Alert
              </Button>
              <Button
                variant="emergency"
                size="lg"
                onClick={handleConfirmEmergency}
                className="w-full"
              >
                <Phone className="h-6 w-6" />
                Call 108 Now
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FallDetection;
