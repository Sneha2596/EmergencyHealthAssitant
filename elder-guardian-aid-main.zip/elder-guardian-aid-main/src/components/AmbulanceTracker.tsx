import { useState, useEffect } from "react";
import { Ambulance, Clock, MapPin, Phone, Navigation } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

const AmbulanceTracker = () => {
  const [isTracking, setIsTracking] = useState(false);
  const [eta, setEta] = useState(8);
  const [progress, setProgress] = useState(0);
  const [ambulanceStatus, setAmbulanceStatus] = useState("Ready");

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTracking && eta > 0) {
      interval = setInterval(() => {
        setEta((prev) => {
          if (prev <= 1) {
            setIsTracking(false);
            setAmbulanceStatus("Arrived");
            return 0;
          }
          return prev - 1;
        });
        setProgress((prev) => Math.min(prev + 12.5, 100));
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [isTracking, eta]);

  const handleRequestAmbulance = () => {
    setIsTracking(true);
    setAmbulanceStatus("Dispatched");
    setEta(8);
    setProgress(0);
  };

  const handleCall108 = () => {
    window.location.href = "tel:108";
  };

  const handleOpenMaps = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords;
        window.open(
          `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}&travelmode=driving`,
          "_blank"
        );
      });
    }
  };

  return (
    <Card className="border-2 border-emergency/30 bg-gradient-to-br from-emergency/5 to-background">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-accessible-lg text-emergency">
          <Ambulance className="h-8 w-8 ambulance-move" />
          Ambulance Tracker
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {!isTracking && ambulanceStatus !== "Arrived" ? (
          <div className="space-y-4">
            <p className="text-accessible-sm text-muted-foreground text-center">
              Request emergency ambulance service (108)
            </p>
            <div className="flex flex-col gap-3">
              <Button
                variant="emergency"
                size="xl"
                onClick={handleRequestAmbulance}
                className="w-full"
              >
                <Ambulance className="h-8 w-8" />
                Request Ambulance
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={handleCall108}
                className="w-full border-emergency text-emergency hover:bg-emergency hover:text-secondary-foreground"
              >
                <Phone className="h-6 w-6" />
                Call 108 Directly
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Status Badge */}
            <div className="flex items-center justify-center">
              <span
                className={`px-6 py-2 rounded-full text-lg font-bold ${
                  ambulanceStatus === "Arrived"
                    ? "bg-success/20 text-success"
                    : "bg-emergency/20 text-emergency fall-alert"
                }`}
              >
                {ambulanceStatus === "Arrived" ? "✓ Ambulance Arrived" : `🚑 ${ambulanceStatus}`}
              </span>
            </div>

            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-base font-medium">
                <span>En Route</span>
                <span>{progress.toFixed(0)}%</span>
              </div>
              <Progress value={progress} className="h-4 bg-emergency/20" />
            </div>

            {/* ETA Display */}
            {ambulanceStatus !== "Arrived" && (
              <div className="bg-muted rounded-2xl p-6 text-center">
                <div className="flex items-center justify-center gap-3 mb-2">
                  <Clock className="h-8 w-8 text-primary" />
                  <span className="text-accessible-2xl font-bold text-primary">
                    {eta} min
                  </span>
                </div>
                <p className="text-muted-foreground text-lg">Estimated arrival time</p>
              </div>
            )}

            {/* Live Location */}
            <div className="flex items-center justify-between bg-primary/10 rounded-xl p-4">
              <div className="flex items-center gap-3">
                <MapPin className="h-6 w-6 text-primary" />
                <div>
                  <p className="font-semibold">Live Location</p>
                  <p className="text-sm text-muted-foreground">Ambulance is tracking your location</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={handleOpenMaps}>
                <Navigation className="h-6 w-6" />
              </Button>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                size="lg"
                onClick={handleCall108}
                className="flex-1"
              >
                <Phone className="h-5 w-5" />
                Call Driver
              </Button>
              <Button
                variant="medical"
                size="lg"
                onClick={handleOpenMaps}
                className="flex-1"
              >
                <MapPin className="h-5 w-5" />
                Track on Map
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AmbulanceTracker;
