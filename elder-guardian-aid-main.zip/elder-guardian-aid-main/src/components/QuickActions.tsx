import { MapPin, Ambulance, Stethoscope, Play, Brain, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";

const actions = [
  {
    icon: MapPin,
    label: "Hospitals",
    href: "#hospitals",
    color: "bg-primary/10 text-primary hover:bg-primary/20",
  },
  {
    icon: Ambulance,
    label: "Ambulance",
    href: "#ambulance",
    color: "bg-emergency/10 text-emergency hover:bg-emergency/20",
  },
  {
    icon: Stethoscope,
    label: "Doctor",
    href: "#doctor",
    color: "bg-success/10 text-success hover:bg-success/20",
  },
  {
    icon: Play,
    label: "First Aid",
    href: "#firstaid",
    color: "bg-warning/10 text-warning hover:bg-warning/20",
  },
  {
    icon: Brain,
    label: "Symptoms",
    href: "#symptoms",
    color: "bg-primary/10 text-primary hover:bg-primary/20",
  },
  {
    icon: Shield,
    label: "Safety",
    href: "#safety",
    color: "bg-success/10 text-success hover:bg-success/20",
  },
];

const QuickActions = () => {
  return (
    <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
      {actions.map((action) => (
        <a
          key={action.label}
          href={action.href}
          className={`flex flex-col items-center gap-2 p-4 rounded-2xl transition-all touch-target ${action.color}`}
        >
          <action.icon className="h-8 w-8" />
          <span className="text-sm font-medium">{action.label}</span>
        </a>
      ))}
    </div>
  );
};

export default QuickActions;
