import { Shield, User, Menu, X, LogOut } from "lucide-react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { User as SupabaseUser } from "@supabase/supabase-js";
import { useLanguage } from "@/contexts/LanguageContext";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const navigate = useNavigate();
  const { t } = useLanguage();

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setIsMenuOpen(false);
    navigate("/");
  };

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center">
              <Shield className="h-7 w-7 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">{t("emergency")}</h1>
              <p className="text-sm text-primary font-medium">Health Assistant</p>
            </div>
          </Link>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <>
                <Button variant="ghost" size="lg" asChild>
                  <Link to="/profile">
                    <User className="h-5 w-5" />
                    {t("profile")}
                  </Link>
                </Button>
                <Button variant="outline" size="lg" onClick={handleSignOut}>
                  <LogOut className="h-5 w-5" />
                  {t("signOut")}
                </Button>
              </>
            ) : (
              <>
                <Button variant="ghost" size="lg" asChild>
                  <Link to="/login">
                    <User className="h-5 w-5" />
                    {t("signIn")}
                  </Link>
                </Button>
                <Button variant="medical" size="lg" asChild>
                  <Link to="/login">Sign Up</Link>
                </Button>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-7 w-7" /> : <Menu className="h-7 w-7" />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-border animate-in slide-in-from-top-2">
            <nav className="flex flex-col gap-3">
              <div className="flex gap-3 pt-3">
                {user ? (
                  <>
                    <Button variant="outline" className="flex-1" asChild>
                      <Link to="/profile" onClick={() => setIsMenuOpen(false)}>
                        <User className="h-4 w-4" />
                        {t("profile")}
                      </Link>
                    </Button>
                    <Button variant="medical" className="flex-1" onClick={handleSignOut}>
                      <LogOut className="h-4 w-4" />
                      {t("signOut")}
                    </Button>
                  </>
                ) : (
                  <>
                    <Button variant="outline" className="flex-1" asChild>
                      <Link to="/login" onClick={() => setIsMenuOpen(false)}>{t("signIn")}</Link>
                    </Button>
                    <Button variant="medical" className="flex-1" asChild>
                      <Link to="/login" onClick={() => setIsMenuOpen(false)}>Sign Up</Link>
                    </Button>
                  </>
                )}
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
