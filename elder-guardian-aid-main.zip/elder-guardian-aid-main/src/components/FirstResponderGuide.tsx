import { AlertCircle, Shield } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const emergencyProtocols = [
  {
    id: "snake-bite",
    title: "Snake Bite",
    icon: "🐍",
    steps: [
      "Keep the victim calm and still - movement spreads venom",
      "Remove jewelry and tight clothing before swelling begins",
      "Position the bitten area below heart level",
      "Clean the bite with soap and water if available",
      "Cover with clean, dry dressing",
      "DO NOT: Cut the wound, apply tourniquet, ice, or try to suck out venom",
      "Call 108 immediately and note snake's appearance if safe"
    ],
    warning: "Get medical help within 30 minutes - antivenom is critical"
  },
  {
    id: "severe-bleeding",
    title: "Severe Bleeding (Hemorrhage)",
    icon: "🩸",
    steps: [
      "Call 108 immediately for severe bleeding",
      "Wear gloves if available to prevent infection",
      "Apply firm, direct pressure with clean cloth/bandage",
      "Maintain pressure for 10-15 minutes without checking",
      "If blood soaks through, add more cloth on top - don't remove first layer",
      "Elevate the injured area above heart level if possible",
      "Apply pressure to arterial pressure points if bleeding continues",
      "DO NOT: Remove embedded objects - stabilize them instead"
    ],
    warning: "Life-threatening if more than 1 liter lost - immediate medical attention required"
  },
  {
    id: "heart-attack",
    title: "Heart Attack",
    icon: "💔",
    steps: [
      "Call 108 immediately - time is critical",
      "Help person sit down and rest in comfortable position",
      "Loosen tight clothing around neck and chest",
      "Give aspirin (300mg) if available and not allergic - ask them to chew it",
      "If prescribed nitroglycerin available, help them take it",
      "Monitor breathing - be ready to perform CPR",
      "Stay calm and reassure the person",
      "DO NOT: Give food or drinks, leave them alone"
    ],
    warning: "Every minute counts - Golden Hour is first 60 minutes"
  },
  {
    id: "choking",
    title: "Choking (Airway Obstruction)",
    icon: "😰",
    steps: [
      "Ask 'Are you choking?' - if can't speak, it's severe",
      "Encourage coughing if they can breathe/speak",
      "For severe choking - perform Heimlich maneuver:",
      "• Stand behind person, wrap arms around waist",
      "• Make fist above navel, below ribcage",
      "• Grasp fist with other hand",
      "• Give quick upward thrusts - 5 times",
      "Alternate with 5 back blows between shoulder blades",
      "Continue until object dislodges or person becomes unconscious",
      "If unconscious, begin CPR and call 108"
    ],
    warning: "Brain damage begins after 4-6 minutes without oxygen"
  },
  {
    id: "burn",
    title: "Severe Burns",
    icon: "🔥",
    steps: [
      "Remove person from heat source safely",
      "Call 108 for large burns or burns on face/hands/genitals",
      "Cool the burn with cool (not ice-cold) running water for 10-20 minutes",
      "Remove jewelry, belts before swelling starts",
      "Cover with sterile, non-stick bandage or clean cloth",
      "DO NOT: Apply ice, butter, oil, or ointments",
      "DO NOT: Break blisters",
      "For chemical burns: flush with water for 20+ minutes",
      "Keep person warm with clean blanket"
    ],
    warning: "3rd degree burns need immediate hospital care - don't delay"
  },
  {
    id: "stroke",
    title: "Stroke (FAST Recognition)",
    icon: "🧠",
    steps: [
      "Use FAST test:",
      "• F - Face: Ask to smile - does one side droop?",
      "• A - Arms: Raise both arms - does one drift down?",
      "• S - Speech: Repeat simple phrase - is it slurred?",
      "• T - Time: Call 108 immediately if any signs present",
      "Note time symptoms started - crucial for treatment",
      "Keep person lying down with head slightly elevated",
      "DO NOT: Give food, drinks, or medications",
      "Monitor breathing until help arrives"
    ],
    warning: "Treatment must start within 4.5 hours - every second matters"
  },
  {
    id: "fracture",
    title: "Fractures (Broken Bones)",
    icon: "🦴",
    steps: [
      "DO NOT move the person unless necessary for safety",
      "Call 108 for serious fractures or if unsure",
      "Immobilize the injured area - don't try to realign",
      "Apply ice packs wrapped in cloth - 20 mins on, 20 mins off",
      "For open fractures: Control bleeding with pressure, don't push bone back",
      "Splint the injury: use rigid material, pad well, immobilize joints above and below",
      "Check circulation: fingertips/toes should be warm and pink",
      "Elevate if possible to reduce swelling",
      "Treat for shock - keep warm and calm"
    ],
    warning: "Spinal fractures require professional handling - do not move victim"
  },
  {
    id: "seizure",
    title: "Seizures",
    icon: "⚡",
    steps: [
      "Stay calm and time the seizure",
      "Move dangerous objects away - create safe space",
      "Cushion head with something soft",
      "Turn person on side to keep airway clear",
      "DO NOT: Hold them down or restrain movements",
      "DO NOT: Put anything in their mouth",
      "Loosen tight clothing around neck",
      "Call 108 if: Seizure lasts over 5 minutes, multiple seizures, first-time seizure, injury occurs, or person has diabetes/pregnancy",
      "After seizure: Stay with them, speak calmly, check breathing"
    ],
    warning: "Time the seizure - call 108 if exceeds 5 minutes"
  }
];

const FirstResponderGuide = () => {
  return (
    <Card className="border-2 border-emergency/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-accessible-lg text-emergency">
          <Shield className="h-8 w-8" />
          First Responder Emergency Protocols
        </CardTitle>
        <p className="text-muted-foreground text-base mt-2">
          Life-saving procedures for immediate emergencies. Always call 108 first.
        </p>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="space-y-2">
          {emergencyProtocols.map((protocol) => (
            <AccordionItem key={protocol.id} value={protocol.id} className="border-2 border-border rounded-xl overflow-hidden">
              <AccordionTrigger className="px-4 py-4 hover:bg-muted/50 text-left">
                <div className="flex items-center gap-3 text-lg font-semibold">
                  <span className="text-3xl">{protocol.icon}</span>
                  <span>{protocol.title}</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-4 pb-4">
                <div className="bg-warning/10 border-l-4 border-warning p-4 rounded-lg mb-4">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="h-5 w-5 text-warning flex-shrink-0 mt-0.5" />
                    <p className="font-semibold text-warning">{protocol.warning}</p>
                  </div>
                </div>
                <ol className="space-y-3">
                  {protocol.steps.map((step, index) => (
                    <li key={index} className="flex gap-3">
                      <span className="font-bold text-primary flex-shrink-0 bg-primary/10 rounded-full w-7 h-7 flex items-center justify-center text-sm">
                        {index + 1}
                      </span>
                      <span className="text-base pt-0.5">{step}</span>
                    </li>
                  ))}
                </ol>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
        
        <div className="mt-6 bg-emergency/10 border-2 border-emergency rounded-xl p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-6 w-6 text-emergency flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-bold text-emergency text-lg mb-2">Emergency Number: 108</h3>
              <p className="text-base">
                For all medical emergencies in India, dial 108 immediately. These protocols are for immediate response while waiting for professional help.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FirstResponderGuide;
