import { Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";

const SOSButton = () => {
  const { toast } = useToast();
  const { t } = useLanguage();

  const sendEmergencyAlerts = async () => {
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Fetch profile with family doctor
      const { data: profile } = await supabase
        .from("profiles")
        .select("family_doctor_phone, full_name")
        .eq("user_id", user.id)
        .single();

      // Fetch family contacts
      const { data: contacts } = await supabase
        .from("family_contacts")
        .select("phone, name")
        .eq("user_id", user.id);

      // Prepare alert message
      const userName = profile?.full_name || "User";
      const alertMessage = `🚨 EMERGENCY ALERT: ${userName} has triggered an SOS emergency call. Please contact immediately!`;

      // Send WhatsApp messages to family doctor
      if (profile?.family_doctor_phone) {
        const doctorUrl = `https://wa.me/${profile.family_doctor_phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(alertMessage)}`;
        window.open(doctorUrl, '_blank');
      }

      // Send WhatsApp messages to family contacts
      if (contacts && contacts.length > 0) {
        contacts.forEach((contact) => {
          const contactUrl = `https://wa.me/${contact.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(alertMessage)}`;
          setTimeout(() => window.open(contactUrl, '_blank'), 500);
        });
      }

      toast({
        title: "Emergency Alerts Sent",
        description: t("emergencyAlertSent"),
        variant: "default",
      });
    } catch (error) {
      console.error("Error sending emergency alerts:", error);
    }
  };

  const handleSOS = () => {
    // Send alerts to family doctor and contacts
    sendEmergencyAlerts();
    
    // Make emergency call to 108
    window.location.href = "tel:108";
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <Button
        variant="emergency"
        size="icon-xl"
        onClick={handleSOS}
        className="relative"
        aria-label="Emergency SOS - Call 108"
      >
        <div className="absolute inset-0 rounded-full bg-emergency/30 animate-pulse-ring" />
        <Phone className="h-12 w-12" />
      </Button>
      <div className="text-center">
        <p className="text-accessible-lg font-bold text-emergency">SOS</p>
        <p className="text-accessible-sm text-muted-foreground">Tap to call 108</p>
      </div>
    </div>
  );
};

export default SOSButton;
