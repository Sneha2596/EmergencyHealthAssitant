import { useState, useEffect } from "react";
import { Heart, Activity, Thermometer, Droplets, Watch, AlertTriangle, Wifi, Bluetooth } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface VitalData {
  heartRate: number;
  bloodPressure: string;
  temperature: number;
  oxygenLevel: number;
  lastUpdated: string;
}

const VitalMonitor = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [showConnectionOptions, setShowConnectionOptions] = useState(false);
  const [vitals, setVitals] = useState<VitalData>({
    heartRate: 72,
    bloodPressure: "120/80",
    temperature: 98.6,
    oxygenLevel: 98,
    lastUpdated: new Date().toLocaleTimeString(),
  });

  const handleBluetoothConnect = () => {
    toast.success("Connecting via Bluetooth...", {
      description: "Searching for nearby wearable devices"
    });
    setTimeout(() => {
      setIsConnected(true);
      setShowConnectionOptions(false);
      toast.success("Device Connected!", {
        description: "Your wearable is now syncing vitals"
      });
    }, 2000);
  };

  const handleWifiConnect = () => {
    toast.success("Connecting via WiFi...", {
      description: "Syncing with your device over WiFi"
    });
    setTimeout(() => {
      setIsConnected(true);
      setShowConnectionOptions(false);
      toast.success("WiFi Connection Successful!", {
        description: "Real-time vital monitoring active"
      });
    }, 2000);
  };

  useEffect(() => {
    if (isConnected) {
      const interval = setInterval(() => {
        setVitals({
          heartRate: Math.floor(Math.random() * 20) + 65,
          bloodPressure: `${Math.floor(Math.random() * 20) + 110}/${Math.floor(Math.random() * 10) + 75}`,
          temperature: (Math.random() * 1 + 98).toFixed(1) as unknown as number,
          oxygenLevel: Math.floor(Math.random() * 4) + 96,
          lastUpdated: new Date().toLocaleTimeString(),
        });
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isConnected]);

  const getHeartRateStatus = (rate: number) => {
    if (rate < 60) return { status: "Low", color: "text-warning" };
    if (rate > 100) return { status: "High", color: "text-emergency" };
    return { status: "Normal", color: "text-success" };
  };

  const getOxygenStatus = (level: number) => {
    if (level < 95) return { status: "Low", color: "text-emergency" };
    return { status: "Normal", color: "text-success" };
  };

  return (
    <Card className="border-2 border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-accessible-lg text-primary">
            <Watch className="h-8 w-8" />
            Vital Monitoring
          </div>
          <span
            className={`px-3 py-1 rounded-full text-sm font-medium ${
              isConnected
                ? "bg-success/20 text-success"
                : "bg-muted text-muted-foreground"
            }`}
          >
            {isConnected ? "● Connected" : "○ Disconnected"}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {!isConnected && !showConnectionOptions ? (
          <div className="text-center space-y-4 py-6">
            <Watch className="h-16 w-16 mx-auto text-muted-foreground" />
            <p className="text-accessible-sm text-muted-foreground">
              Connect your wearable device to monitor vitals
            </p>
            <Button
              variant="medical"
              size="lg"
              onClick={() => setShowConnectionOptions(true)}
            >
              <Watch className="h-6 w-6" />
              Connect Wearable
            </Button>
          </div>
        ) : !isConnected && showConnectionOptions ? (
          <div className="space-y-4 py-6">
            <h3 className="text-center text-lg font-semibold mb-4">Choose Connection Method</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Button
                variant="outline"
                size="lg"
                onClick={handleBluetoothConnect}
                className="h-auto py-6 flex flex-col items-center gap-3 hover:border-primary hover:bg-primary/5"
              >
                <Bluetooth className="h-12 w-12 text-primary" />
                <div className="text-center">
                  <p className="font-semibold text-base">Bluetooth</p>
                  <p className="text-sm text-muted-foreground">For smartwatches & fitness bands</p>
                </div>
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={handleWifiConnect}
                className="h-auto py-6 flex flex-col items-center gap-3 hover:border-primary hover:bg-primary/5"
              >
                <Wifi className="h-12 w-12 text-primary" />
                <div className="text-center">
                  <p className="font-semibold text-base">WiFi</p>
                  <p className="text-sm text-muted-foreground">For home health monitors</p>
                </div>
              </Button>
            </div>
            <Button
              variant="ghost"
              onClick={() => setShowConnectionOptions(false)}
              className="w-full mt-2"
            >
              Cancel
            </Button>
          </div>
        ) : (
          <>
            {/* Vital Cards Grid */}
            <div className="grid grid-cols-2 gap-4">
              {/* Heart Rate */}
              <div className="bg-emergency/10 rounded-2xl p-4 text-center vital-pulse">
                <Heart className="h-8 w-8 mx-auto text-emergency mb-2" />
                <p className="text-3xl font-bold text-emergency">{vitals.heartRate}</p>
                <p className="text-sm text-muted-foreground">BPM</p>
                <span className={`text-xs font-medium ${getHeartRateStatus(vitals.heartRate).color}`}>
                  {getHeartRateStatus(vitals.heartRate).status}
                </span>
              </div>

              {/* Oxygen Level */}
              <div className="bg-primary/10 rounded-2xl p-4 text-center">
                <Droplets className="h-8 w-8 mx-auto text-primary mb-2" />
                <p className="text-3xl font-bold text-primary">{vitals.oxygenLevel}%</p>
                <p className="text-sm text-muted-foreground">SpO2</p>
                <span className={`text-xs font-medium ${getOxygenStatus(vitals.oxygenLevel).color}`}>
                  {getOxygenStatus(vitals.oxygenLevel).status}
                </span>
              </div>

              {/* Blood Pressure */}
              <div className="bg-success/10 rounded-2xl p-4 text-center">
                <Activity className="h-8 w-8 mx-auto text-success mb-2" />
                <p className="text-2xl font-bold text-success">{vitals.bloodPressure}</p>
                <p className="text-sm text-muted-foreground">mmHg</p>
                <span className="text-xs font-medium text-success">Normal</span>
              </div>

              {/* Temperature */}
              <div className="bg-warning/10 rounded-2xl p-4 text-center">
                <Thermometer className="h-8 w-8 mx-auto text-warning mb-2" />
                <p className="text-3xl font-bold text-warning">{vitals.temperature}°F</p>
                <p className="text-sm text-muted-foreground">Body Temp</p>
                <span className="text-xs font-medium text-success">Normal</span>
              </div>
            </div>

            {/* Last Updated */}
            <p className="text-center text-sm text-muted-foreground">
              Last updated: {vitals.lastUpdated}
            </p>

            {/* Alert Thresholds */}
            <div className="bg-muted rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-5 w-5 text-warning" />
                <span className="font-semibold">Auto-Alert Enabled</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Emergency contacts will be notified if vitals fall outside safe ranges
              </p>
            </div>

            <Button
              variant="outline"
              size="lg"
              onClick={() => setIsConnected(false)}
              className="w-full"
            >
              Disconnect Device
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default VitalMonitor;
