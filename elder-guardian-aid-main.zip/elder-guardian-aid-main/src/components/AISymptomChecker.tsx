import { useState } from "react";
import { Brain, Send, AlertCircle, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface SymptomResult {
  severity: "mild" | "moderate" | "severe";
  recommendation: string;
  possibleConditions: string[];
  seekHelp: boolean;
}

const AISymptomChecker = () => {
  const [symptoms, setSymptoms] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<SymptomResult | null>(null);

  const analyzeSymptoms = () => {
    if (!symptoms.trim()) return;

    setIsAnalyzing(true);
    setResult(null);

    // Simulate AI analysis
    setTimeout(() => {
      const lowerSymptoms = symptoms.toLowerCase();
      let severity: "mild" | "moderate" | "severe" = "mild";
      let seekHelp = false;

      // Simple keyword-based severity detection
      if (
        lowerSymptoms.includes("chest pain") ||
        lowerSymptoms.includes("difficulty breathing") ||
        lowerSymptoms.includes("severe") ||
        lowerSymptoms.includes("unconscious")
      ) {
        severity = "severe";
        seekHelp = true;
      } else if (
        lowerSymptoms.includes("fever") ||
        lowerSymptoms.includes("vomiting") ||
        lowerSymptoms.includes("dizzy")
      ) {
        severity = "moderate";
      }

      const recommendations: Record<string, string> = {
        mild: "Rest and monitor your symptoms. Stay hydrated and get adequate sleep. If symptoms persist beyond 48 hours, consult a doctor.",
        moderate: "Consider consulting a doctor within 24 hours. Monitor for worsening symptoms. Keep emergency contacts ready.",
        severe: "Seek immediate medical attention! Call 108 or visit the nearest emergency room immediately.",
      };

      const conditions: Record<string, string[]> = {
        mild: ["Common cold", "Mild allergies", "Minor fatigue"],
        moderate: ["Viral infection", "Dehydration", "Stress-related symptoms"],
        severe: ["Requires immediate medical evaluation"],
      };

      setResult({
        severity,
        recommendation: recommendations[severity],
        possibleConditions: conditions[severity],
        seekHelp,
      });
      setIsAnalyzing(false);
    }, 2000);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "mild":
        return "bg-success/20 text-success border-success";
      case "moderate":
        return "bg-warning/20 text-warning border-warning";
      case "severe":
        return "bg-emergency/20 text-emergency border-emergency";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <Card className="border-2 border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-accessible-lg text-primary">
          <Brain className="h-8 w-8" />
          AI Symptom Checker
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-3">
          <label className="text-lg font-medium">
            Describe your symptoms in detail:
          </label>
          <Textarea
            placeholder="Example: I have a headache, mild fever, and feeling tired for 2 days..."
            value={symptoms}
            onChange={(e) => setSymptoms(e.target.value)}
            className="min-h-[120px] text-lg rounded-xl resize-none"
          />
          <Button
            variant="medical"
            size="lg"
            onClick={analyzeSymptoms}
            disabled={!symptoms.trim() || isAnalyzing}
            className="w-full"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="h-6 w-6 animate-spin" />
                Analyzing Symptoms...
              </>
            ) : (
              <>
                <Send className="h-6 w-6" />
                Analyze Symptoms
              </>
            )}
          </Button>
        </div>

        {result && (
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Severity Badge */}
            <div
              className={`p-4 rounded-2xl border-2 ${getSeverityColor(result.severity)}`}
            >
              <div className="flex items-center gap-3 mb-2">
                <AlertCircle className="h-6 w-6" />
                <span className="text-xl font-bold capitalize">
                  {result.severity} Severity
                </span>
              </div>
              <p className="text-base">{result.recommendation}</p>
            </div>

            {/* Possible Conditions */}
            <div className="bg-muted rounded-xl p-4">
              <h4 className="font-semibold mb-2">Possible Conditions:</h4>
              <ul className="space-y-1">
                {result.possibleConditions.map((condition, index) => (
                  <li key={index} className="flex items-center gap-2 text-muted-foreground">
                    <span className="w-2 h-2 rounded-full bg-primary" />
                    {condition}
                  </li>
                ))}
              </ul>
            </div>

            {/* Emergency Action */}
            {result.seekHelp && (
              <Button
                variant="emergency"
                size="xl"
                onClick={() => (window.location.href = "tel:108")}
                className="w-full"
              >
                <AlertCircle className="h-8 w-8" />
                Call 108 Emergency Now
              </Button>
            )}

            {/* Disclaimer */}
            <p className="text-xs text-muted-foreground text-center">
              ⚠️ This is not a medical diagnosis. Always consult a healthcare professional for proper medical advice.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AISymptomChecker;
