import { useState } from "react";
import { Stethoscope, Phone, Video, MessageCircle, Clock, Star, UserCheck } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface Doctor {
  id: number;
  name: string;
  specialty: string;
  rating: number;
  experience: string;
  available: boolean;
  waitTime: string;
  languages: string[];
}

const doctors: Doctor[] = [
  {
    id: 1,
    name: "Dr. Priya Sharma",
    specialty: "General Physician",
    rating: 4.9,
    experience: "15 years",
    available: true,
    waitTime: "2 min",
    languages: ["Hindi", "English"],
  },
  {
    id: 2,
    name: "Dr. Rajesh Kumar",
    specialty: "Cardiologist",
    rating: 4.8,
    experience: "20 years",
    available: true,
    waitTime: "5 min",
    languages: ["Hindi", "English", "Tamil"],
  },
  {
    id: 3,
    name: "Dr. Anjali Patel",
    specialty: "Emergency Medicine",
    rating: 4.9,
    experience: "12 years",
    available: false,
    waitTime: "15 min",
    languages: ["Hindi", "English", "Gujarati"],
  },
];

const DoctorOnCall = () => {
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);

  const handleVideoCall = (doctor: Doctor) => {
    alert(`Starting video call with ${doctor.name}...`);
  };

  const handleVoiceCall = (doctor: Doctor) => {
    alert(`Calling ${doctor.name}...`);
  };

  const handleChat = (doctor: Doctor) => {
    alert(`Opening chat with ${doctor.name}...`);
  };

  return (
    <Card className="border-2 border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-accessible-lg text-primary">
          <Stethoscope className="h-8 w-8" />
          Doctor On-Call (24/7)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-muted-foreground">
          Connect with verified doctors instantly for medical consultation
        </p>

        {/* Doctor List */}
        <div className="space-y-4">
          {doctors.map((doctor) => (
            <div
              key={doctor.id}
              className={`p-4 rounded-2xl border-2 transition-all ${
                selectedDoctor?.id === doctor.id
                  ? "border-primary bg-primary/5"
                  : "border-border hover:border-primary/50"
              }`}
              onClick={() => setSelectedDoctor(doctor)}
            >
              <div className="flex items-start justify-between">
                <div className="flex gap-4">
                  <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center">
                    <UserCheck className="h-7 w-7 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">{doctor.name}</h3>
                    <p className="text-muted-foreground">{doctor.specialty}</p>
                    <div className="flex items-center gap-3 mt-1 text-sm">
                      <span className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-warning text-warning" />
                        {doctor.rating}
                      </span>
                      <span className="text-muted-foreground">
                        {doctor.experience}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-medium ${
                      doctor.available
                        ? "bg-success/20 text-success"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {doctor.available ? "Available" : "Busy"}
                  </span>
                  <div className="flex items-center gap-1 mt-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    Wait: {doctor.waitTime}
                  </div>
                </div>
              </div>

              {/* Languages */}
              <div className="mt-3 flex gap-2">
                {doctor.languages.map((lang) => (
                  <span
                    key={lang}
                    className="px-2 py-1 bg-muted rounded-lg text-xs"
                  >
                    {lang}
                  </span>
                ))}
              </div>

              {/* Action Buttons */}
              {selectedDoctor?.id === doctor.id && (
                <div className="mt-4 flex gap-3">
                  <Button
                    variant="medical"
                    size="lg"
                    onClick={() => handleVideoCall(doctor)}
                    disabled={!doctor.available}
                    className="flex-1"
                  >
                    <Video className="h-5 w-5" />
                    Video Call
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    onClick={() => handleVoiceCall(doctor)}
                    disabled={!doctor.available}
                    className="flex-1"
                  >
                    <Phone className="h-5 w-5" />
                    Voice Call
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleChat(doctor)}
                  >
                    <MessageCircle className="h-6 w-6" />
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Emergency Notice */}
        <div className="bg-emergency/10 rounded-xl p-4 text-center">
          <p className="text-sm text-emergency font-medium">
            For life-threatening emergencies, call 108 immediately
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default DoctorOnCall;
