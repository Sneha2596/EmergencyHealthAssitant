import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export type Language = "en" | "hi" | "kn";

interface Translations {
  [key: string]: {
    en: string;
    hi: string;
    kn: string;
  };
}

const translations: Translations = {
  // Navigation & Common
  home: { en: "Home", hi: "होम", kn: "ಮನೆ" },
  profile: { en: "Profile", hi: "प्रोफ़ाइल", kn: "ಪ್ರೊಫೈಲ್" },
  signOut: { en: "Sign Out", hi: "साइन आउट", kn: "ಸೈನ್ ಔಟ್" },
  signIn: { en: "Sign In", hi: "साइन इन", kn: "ಸೈನ್ ಇನ್" },
  save: { en: "Save", hi: "सहेजें", kn: "ಉಳಿಸಿ" },
  cancel: { en: "Cancel", hi: "रद्द करें", kn: "ರದ್ದುಮಾಡಿ" },
  edit: { en: "Edit", hi: "संपादित करें", kn: "ತಿದ್ದು" },
  add: { en: "Add", hi: "जोड़ें", kn: "ಸೇರಿಸಿ" },
  search: { en: "Search", hi: "खोजें", kn: "ಹುಡುಕಿ" },
  loading: { en: "Loading...", hi: "लोड हो रहा है...", kn: "ಲೋಡ್ ಆಗುತ್ತಿದೆ..." },
  
  // Hero Section
  emergencyHealthAssistant: { en: "Emergency Health Assistant", hi: "आपातकालीन स्वास्थ्य सहायक", kn: "ತುರ್ತು ಆರೋಗ್ಯ ಸಹಾಯಕ" },
  heroDescription: { 
    en: "Your 24/7 health emergency companion. Tap any feature below to access emergency services.", 
    hi: "आपका 24/7 स्वास्थ्य आपातकालीन साथी। आपातकालीन सेवाओं तक पहुंचने के लिए नीचे किसी भी सुविधा पर टैप करें।", 
    kn: "ನಿಮ್ಮ 24/7 ಆರೋಗ್ಯ ತುರ್ತು ಸಂಗಾತಿ. ತುರ್ತು ಸೇವೆಗಳನ್ನು ಪ್ರವೇಶಿಸಲು ಕೆಳಗಿನ ಯಾವುದೇ ವೈಶಿಷ್ಟ್ಯವನ್ನು ಟ್ಯಾಪ್ ಮಾಡಿ." 
  },
  
  // Feature Cards
  findHospitals: { en: "Find Hospitals", hi: "अस्पताल खोजें", kn: "ಆಸ್ಪತ್ರೆಗಳನ್ನು ಹುಡುಕಿ" },
  hospitalsDesc: { en: "Locate nearby hospitals and clinics", hi: "पास के अस्पताल और क्लीनिक खोजें", kn: "ಹತ್ತಿರದ ಆಸ್ಪತ್ರೆಗಳು ಮತ್ತು ಕ್ಲಿನಿಕ್‌ಗಳನ್ನು ಹುಡುಕಿ" },
  ambulance: { en: "Ambulance", hi: "एम्बुलेंस", kn: "ಆಂಬುಲೆನ್ಸ್" },
  ambulanceDesc: { en: "Track and request emergency ambulance", hi: "आपातकालीन एम्बुलेंस को ट्रैक करें और अनुरोध करें", kn: "ತುರ್ತು ಆಂಬುಲೆನ್ಸ್ ಅನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ ಮತ್ತು ವಿನಂತಿಸಿ" },
  doctorOnCall: { en: "Doctor On-Call", hi: "डॉक्टर ऑन-कॉल", kn: "ಡಾಕ್ಟರ್ ಆನ್-ಕಾಲ್" },
  doctorDesc: { en: "Connect with available doctors instantly", hi: "तुरंत उपलब्ध डॉक्टरों से जुड़ें", kn: "ತಕ್ಷಣ ಲಭ್ಯವಿರುವ ವೈದ್ಯರೊಂದಿಗೆ ಸಂಪರ್ಕಿಸಿ" },
  firstAid: { en: "First Aid", hi: "प्राथमिक चिकित्सा", kn: "ಪ್ರಥಮ ಚಿಕಿತ್ಸೆ" },
  firstAidDesc: { en: "Learn emergency first aid techniques", hi: "आपातकालीन प्राथमिक चिकित्सा तकनीक सीखें", kn: "ತುರ್ತು ಪ್ರಥಮ ಚಿಕಿತ್ಸಾ ತಂತ್ರಗಳನ್ನು ಕಲಿಯಿರಿ" },
  symptomChecker: { en: "Symptom Checker", hi: "लक्षण परीक्षक", kn: "ರೋಗಲಕ್ಷಣ ಪರೀಕ್ಷಕ" },
  symptomDesc: { en: "AI-powered health assessment", hi: "AI-संचालित स्वास्थ्य मूल्यांकन", kn: "AI-ಚಾಲಿತ ಆರೋಗ್ಯ ಮೌಲ್ಯಮಾಪನ" },
  safetyTips: { en: "Safety Tips", hi: "सुरक्षा युक्तियाँ", kn: "ಸುರಕ್ಷತಾ ಸಲಹೆಗಳು" },
  safetyDesc: { en: "Fall detection & vital monitoring", hi: "गिरने का पता लगाना और महत्वपूर्ण निगरानी", kn: "ಬೀಳುವಿಕೆ ಪತ್ತೆ ಮತ್ತು ಪ್ರಮುಖ ಮಾನಿಟರಿಂಗ್" },
  
  // First Aid
  searchFirstAid: { en: "Search first aid videos...", hi: "प्राथमिक चिकित्सा वीडियो खोजें...", kn: "ಪ್ರಥಮ ಚಿಕಿತ್ಸಾ ವೀಡಿಯೊಗಳನ್ನು ಹುಡುಕಿ..." },
  firstAidVideos: { en: "First Aid Videos", hi: "प्राथमिक चिकित्सा वीडियो", kn: "ಪ್ರಥಮ ಚಿಕಿತ್ಸಾ ವೀಡಿಯೊಗಳು" },
  searchForVideos: { en: "Search for first aid topics like CPR, choking, burns, bleeding...", hi: "सीपीआर, घुटन, जलन, रक्तस्राव जैसे प्राथमिक चिकित्सा विषयों को खोजें...", kn: "CPR, ಉಸಿರುಗಟ್ಟುವಿಕೆ, ಸುಡುವಿಕೆ, ರಕ್ತಸ್ರಾವ ಮುಂತಾದ ಪ್ರಥಮ ಚಿಕಿತ್ಸಾ ವಿಷಯಗಳನ್ನು ಹುಡುಕಿ..." },
  watchOnYoutube: { en: "Watch on YouTube", hi: "यूट्यूब पर देखें", kn: "YouTube ನಲ್ಲಿ ವೀಕ್ಷಿಸಿ" },
  noVideosFound: { en: "No videos found. Try searching for CPR, choking, burns, etc.", hi: "कोई वीडियो नहीं मिला। सीपीआर, घुटन, जलन आदि खोजने का प्रयास करें।", kn: "ಯಾವುದೇ ವೀಡಿಯೊಗಳು ಕಂಡುಬಂದಿಲ್ಲ. CPR, ಉಸಿರುಗಟ್ಟುವಿಕೆ, ಸುಡುವಿಕೆ ಇತ್ಯಾದಿಗಳನ್ನು ಹುಡುಕಲು ಪ್ರಯತ್ನಿಸಿ." },
  
  // Profile
  myProfile: { en: "My Profile", hi: "मेरी प्रोफ़ाइल", kn: "ನನ್ನ ಪ್ರೊಫೈಲ್" },
  fullName: { en: "Full Name", hi: "पूरा नाम", kn: "ಪೂರ್ಣ ಹೆಸರು" },
  phone: { en: "Phone", hi: "फ़ोन", kn: "ಫೋನ್" },
  bloodGroup: { en: "Blood Group", hi: "रक्त समूह", kn: "ರಕ್ತದ ಗುಂಪು" },
  medicalConditions: { en: "Medical Conditions", hi: "चिकित्सा स्थितियां", kn: "ವೈದ್ಯಕೀಯ ಪರಿಸ್ಥಿತಿಗಳು" },
  allergies: { en: "Allergies", hi: "एलर्जी", kn: "ಅಲರ್ಜಿಗಳು" },
  notSet: { en: "Not set", hi: "सेट नहीं", kn: "ಹೊಂದಿಸಲಾಗಿಲ್ಲ" },
  none: { en: "None", hi: "कोई नहीं", kn: "ಯಾವುದೂ ಇಲ್ಲ" },
  familyContacts: { en: "Family Contacts", hi: "परिवार के संपर्क", kn: "ಕುಟುಂಬ ಸಂಪರ್ಕಗಳು" },
  primaryContact: { en: "Primary Contact", hi: "प्राथमिक संपर्क", kn: "ಪ್ರಾಥಮಿಕ ಸಂಪರ್ಕ" },
  noContacts: { en: "No family contacts added yet. Add emergency contacts to notify in case of emergencies.", hi: "अभी तक कोई परिवार संपर्क नहीं जोड़ा गया। आपात स्थिति में सूचित करने के लिए आपातकालीन संपर्क जोड़ें।", kn: "ಇನ್ನೂ ಯಾವುದೇ ಕುಟುಂಬ ಸಂಪರ್ಕಗಳನ್ನು ಸೇರಿಸಲಾಗಿಲ್ಲ. ತುರ್ತು ಸಂದರ್ಭಗಳಲ್ಲಿ ತಿಳಿಸಲು ತುರ್ತು ಸಂಪರ್ಕಗಳನ್ನು ಸೇರಿಸಿ." },
  contactName: { en: "Contact Name", hi: "संपर्क का नाम", kn: "ಸಂಪರ್ಕ ಹೆಸರು" },
  relationship: { en: "Relationship", hi: "संबंध", kn: "ಸಂಬಂಧ" },
  saveContact: { en: "Save Contact", hi: "संपर्क सहेजें", kn: "ಸಂಪರ್ಕವನ್ನು ಉಳಿಸಿ" },
  language: { en: "Language", hi: "भाषा", kn: "ಭಾಷೆ" },
  selectLanguage: { en: "Select Language", hi: "भाषा चुनें", kn: "ಭಾಷೆಯನ್ನು ಆಯ್ಕೆಮಾಡಿ" },
  
  // Emergency Numbers
  emergencyNumbers: { en: "Emergency Numbers - India", hi: "आपातकालीन नंबर - भारत", kn: "ತುರ್ತು ಸಂಖ್ಯೆಗಳು - ಭಾರತ" },
  emergency: { en: "Emergency", hi: "आपातकालीन", kn: "ತುರ್ತು" },
  police: { en: "Police", hi: "पुलिस", kn: "ಪೊಲೀಸ್" },
  fire: { en: "Fire", hi: "अग्निशमन", kn: "ಬೆಂಕಿ" },
  
  // SOS
  sosEmergency: { en: "SOS EMERGENCY", hi: "एसओएस आपातकाल", kn: "SOS ತುರ್ತು" },
  tapForHelp: { en: "Tap for immediate help", hi: "तुरंत मदद के लिए टैप करें", kn: "ತಕ್ಷಣ ಸಹಾಯಕ್ಕಾಗಿ ಟ್ಯಾಪ್ ಮಾಡಿ" },
  
  // Footer
  footerText: { en: "Emergency Health Assistant © 2025 | Designed for India", hi: "आपातकालीन स्वास्थ्य सहायक © 2025 | भारत के लिए डिज़ाइन किया गया", kn: "ತುರ್ತು ಆರೋಗ್ಯ ಸಹಾಯಕ © 2025 | ಭಾರತಕ್ಕಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿದೆ" },
  footerNote: { en: "For medical emergencies, always call 108 first", hi: "चिकित्सा आपात स्थिति के लिए, हमेशा पहले 108 पर कॉल करें", kn: "ವೈದ್ಯಕೀಯ ತುರ್ತು ಸಂದರ್ಭಗಳಲ್ಲಿ, ಯಾವಾಗಲೂ ಮೊದಲು 108 ಗೆ ಕರೆ ಮಾಡಿ" },
  
  // Family Doctor
  familyDoctorPhone: { en: "Family Doctor", hi: "परिवार के डॉक्टर", kn: "ಕುಟುಂಬ ವೈದ್ಯರು" },
  familyDoctorNote: { en: "In case of emergency, alerts will be sent to your family doctor", hi: "आपातकाल की स्थिति में, आपके परिवार के डॉक्टर को अलर्ट भेजा जाएगा", kn: "ತುರ್ತು ಸಂದರ್ಭದಲ್ಲಿ, ನಿಮ್ಮ ಕುಟುಂಬ ವೈದ್ಯರಿಗೆ ಎಚ್ಚರಿಕೆಗಳನ್ನು ಕಳುಹಿಸಲಾಗುವುದು" },
  emergencyAlertSent: { en: "Emergency alert sent to your family doctor and contacts!", hi: "आपके परिवार के डॉक्टर और संपर्कों को आपातकालीन अलर्ट भेजा गया!", kn: "ನಿಮ್ಮ ಕುಟುಂಬ ವೈದ್ಯರು ಮತ್ತು ಸಂಪರ್ಕಗಳಿಗೆ ತುರ್ತು ಎಚ್ಚರಿಕೆ ಕಳುಹಿಸಲಾಗಿದೆ!" },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem("app-language");
    return (saved as Language) || "en";
  });

  useEffect(() => {
    localStorage.setItem("app-language", language);
  }, [language]);

  const t = (key: string): string => {
    const translation = translations[key];
    if (!translation) return key;
    return translation[language] || translation.en || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
};
