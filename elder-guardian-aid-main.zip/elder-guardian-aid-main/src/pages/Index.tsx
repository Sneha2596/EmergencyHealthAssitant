import { useState } from "react";
import { MapPin, Truck, Stethoscope, Play, Activity, Shield, ChevronDown, ChevronUp, AlertCircle } from "lucide-react";
import Header from "@/components/Header";
import SOSButton from "@/components/SOSButton";
import HospitalLocator from "@/components/HospitalLocator";
import AmbulanceTracker from "@/components/AmbulanceTracker";
import FirstAidVideos from "@/components/FirstAidVideos";
import FirstResponderGuide from "@/components/FirstResponderGuide";
import AISymptomChecker from "@/components/AISymptomChecker";
import DoctorOnCall from "@/components/DoctorOnCall";
import VitalMonitor from "@/components/VitalMonitor";
import FallDetection from "@/components/FallDetection";
import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";

type FeatureKey = "hospitals" | "ambulance" | "doctor" | "firstaid" | "protocols" | "symptoms" | "safety" | null;

const Index = () => {
  const [expandedFeature, setExpandedFeature] = useState<FeatureKey>(null);
  const { t } = useLanguage();

  const features = [
    {
      key: "hospitals" as FeatureKey,
      icon: MapPin,
      title: t("findHospitals"),
      description: t("hospitalsDesc"),
      color: "bg-primary",
      component: <HospitalLocator />,
    },
    {
      key: "ambulance" as FeatureKey,
      icon: Truck,
      title: t("ambulance"),
      description: t("ambulanceDesc"),
      color: "bg-destructive",
      component: <AmbulanceTracker />,
    },
    {
      key: "doctor" as FeatureKey,
      icon: Stethoscope,
      title: t("doctorOnCall"),
      description: t("doctorDesc"),
      color: "bg-emerald-500",
      component: <DoctorOnCall />,
    },
    {
      key: "firstaid" as FeatureKey,
      icon: Play,
      title: t("firstAid"),
      description: t("firstAidDesc"),
      color: "bg-amber-500",
      component: <FirstAidVideos />,
    },
    {
      key: "protocols" as FeatureKey,
      icon: AlertCircle,
      title: "First Responder",
      description: "Emergency protocols & immediate care steps",
      color: "bg-destructive",
      component: <FirstResponderGuide />,
    },
    {
      key: "symptoms" as FeatureKey,
      icon: Activity,
      title: t("symptomChecker"),
      description: t("symptomDesc"),
      color: "bg-violet-500",
      component: <AISymptomChecker />,
    },
    {
      key: "safety" as FeatureKey,
      icon: Shield,
      title: t("safetyTips"),
      description: t("safetyDesc"),
      color: "bg-cyan-500",
      component: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <VitalMonitor />
          <FallDetection />
        </div>
      ),
    },
  ];

  const toggleFeature = (key: FeatureKey) => {
    setExpandedFeature(expandedFeature === key ? null : key);
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Health-themed Background */}
      <div 
        className="fixed inset-0 -z-10"
        style={{ background: "var(--gradient-health-bg)" }}
      />
      
      {/* Decorative Medical Elements */}
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        {/* Heartbeat Line SVG */}
        <svg 
          className="absolute top-20 left-0 w-full h-32 opacity-[0.08]" 
          viewBox="0 0 1200 100" 
          preserveAspectRatio="none"
        >
          <path 
            d="M0,50 L200,50 L220,50 L240,20 L260,80 L280,30 L300,70 L320,50 L400,50 L1200,50" 
            fill="none" 
            stroke="hsl(217 91% 50%)" 
            strokeWidth="3"
            className="animate-pulse"
          />
        </svg>
        
        {/* Medical Cross Patterns */}
        <div className="absolute top-40 right-10 w-20 h-20 opacity-[0.05]">
          <div className="absolute top-1/2 left-0 w-full h-4 bg-primary -translate-y-1/2 rounded-full" />
          <div className="absolute top-0 left-1/2 w-4 h-full bg-primary -translate-x-1/2 rounded-full" />
        </div>
        <div className="absolute bottom-40 left-10 w-16 h-16 opacity-[0.05]">
          <div className="absolute top-1/2 left-0 w-full h-3 bg-destructive -translate-y-1/2 rounded-full" />
          <div className="absolute top-0 left-1/2 w-3 h-full bg-destructive -translate-x-1/2 rounded-full" />
        </div>
        
        {/* Floating Circles */}
        <div className="absolute top-1/4 right-1/4 w-64 h-64 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-48 h-48 rounded-full bg-success/5 blur-3xl" />
      </div>
      
      <Header />
      
      <main className="container mx-auto px-4 py-6 space-y-6 relative z-10">
        {/* Hero Section with SOS */}
        <section className="text-center space-y-4 py-6">
          <div className="space-y-2">
            <h1 className="text-accessible-2xl md:text-accessible-3xl font-bold text-foreground">
              {t("emergencyHealthAssistant")}
            </h1>
            <p className="text-accessible-sm text-muted-foreground max-w-2xl mx-auto">
              {t("heroDescription")}
            </p>
          </div>
          
          {/* SOS Button */}
          <div className="py-4">
            <SOSButton />
          </div>
        </section>

        {/* Feature Cards Grid */}
        <section className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {features.map((feature) => (
            <Card
              key={feature.key}
              className={`cursor-pointer transition-all duration-300 border-2 ${
                expandedFeature === feature.key 
                  ? "border-primary ring-2 ring-primary/20" 
                  : "border-border hover:border-primary/50"
              }`}
              onClick={() => toggleFeature(feature.key)}
            >
              <CardContent className="p-4 text-center">
                <div className={`${feature.color} w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-3`}>
                  <feature.icon className="h-7 w-7 text-white" />
                </div>
                <h3 className="font-bold text-base md:text-lg text-foreground mb-1">
                  {feature.title}
                </h3>
                <p className="text-xs md:text-sm text-muted-foreground mb-2">
                  {feature.description}
                </p>
                <div className="flex justify-center">
                  {expandedFeature === feature.key ? (
                    <ChevronUp className="h-5 w-5 text-primary" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </section>

        {/* Expanded Feature Content */}
        {expandedFeature && (
          <section className="animate-in slide-in-from-top-4 duration-300">
            {features.find((f) => f.key === expandedFeature)?.component}
          </section>
        )}

        {/* Emergency Info Footer */}
        <section className="bg-destructive/10 rounded-3xl p-6 md:p-8 text-center">
          <h2 className="text-accessible-lg font-bold text-destructive mb-4">
            {t("emergencyNumbers")}
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { number: "108", label: t("ambulance") },
              { number: "112", label: t("emergency") },
              { number: "100", label: t("police") },
              { number: "101", label: t("fire") },
            ].map((item) => (
              <a
                key={item.number}
                href={`tel:${item.number}`}
                className="bg-background rounded-2xl p-4 card-hover"
              >
                <p className="text-3xl font-bold text-destructive">{item.number}</p>
                <p className="text-muted-foreground">{item.label}</p>
              </a>
            ))}
          </div>
        </section>

        {/* Footer */}
        <footer className="text-center py-8 border-t border-border">
          <p className="text-muted-foreground">
            {t("footerText")}
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            {t("footerNote")}
          </p>
        </footer>
      </main>
    </div>
  );
};

export default Index;
