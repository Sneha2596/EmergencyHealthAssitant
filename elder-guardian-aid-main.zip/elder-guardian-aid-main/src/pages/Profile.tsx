import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { 
  User, Phone, Heart, AlertTriangle, Plus, Trash2, 
  LogOut, ArrowLeft, Users, Edit2, Save, X, Globe 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Link } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";

interface Profile {
  id: string;
  full_name: string | null;
  phone: string | null;
  blood_group: string | null;
  medical_conditions: string | null;
  allergies: string | null;
  family_doctor_phone: string | null;
}

interface FamilyContact {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  is_primary: boolean;
}

const Profile = () => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [familyContacts, setFamilyContacts] = useState<FamilyContact[]>([]);
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [editedProfile, setEditedProfile] = useState<Partial<Profile>>({});
  const [newContact, setNewContact] = useState({ name: "", relationship: "", phone: "" });
  const [showAddContact, setShowAddContact] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const { language, setLanguage, t } = useLanguage();

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) {
        navigate("/login");
      }
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        navigate("/login");
      } else {
        fetchProfile();
        fetchFamilyContacts();
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const fetchProfile = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("user_id", user.id)
      .maybeSingle();

    if (error) {
      console.error("Error fetching profile:", error);
    } else if (data) {
      setProfile(data);
      setEditedProfile(data);
    }
    setLoading(false);
  };

  const fetchFamilyContacts = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from("family_contacts")
      .select("*")
      .eq("user_id", user.id)
      .order("is_primary", { ascending: false });

    if (error) {
      console.error("Error fetching contacts:", error);
    } else {
      setFamilyContacts(data || []);
    }
  };

  const handleSaveProfile = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: editedProfile.full_name,
        phone: editedProfile.phone,
        blood_group: editedProfile.blood_group,
        medical_conditions: editedProfile.medical_conditions,
        allergies: editedProfile.allergies,
        family_doctor_phone: editedProfile.family_doctor_phone,
      })
      .eq("user_id", user.id);

    if (error) {
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
      setProfile({ ...profile, ...editedProfile } as Profile);
      setEditing(false);
    }
  };

  const handleAddContact = async () => {
    if (!newContact.name || !newContact.relationship || !newContact.phone) {
      toast({
        title: "Error",
        description: "Please fill all contact fields",
        variant: "destructive",
      });
      return;
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { error } = await supabase
      .from("family_contacts")
      .insert({
        user_id: user.id,
        name: newContact.name,
        relationship: newContact.relationship,
        phone: newContact.phone,
        is_primary: familyContacts.length === 0,
      });

    if (error) {
      toast({
        title: "Error",
        description: "Failed to add contact",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Success",
        description: "Contact added successfully",
      });
      setNewContact({ name: "", relationship: "", phone: "" });
      setShowAddContact(false);
      fetchFamilyContacts();
    }
  };

  const handleDeleteContact = async (id: string) => {
    const { error } = await supabase
      .from("family_contacts")
      .delete()
      .eq("id", id);

    if (error) {
      toast({
        title: "Error",
        description: "Failed to delete contact",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Success",
        description: "Contact removed",
      });
      fetchFamilyContacts();
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-primary/5 to-background flex items-center justify-center">
        <p className="text-xl text-muted-foreground">{t("loading")}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 to-background">
      {/* Header */}
      <header className="p-4 flex justify-between items-center">
        <Button variant="ghost" size="lg" asChild>
          <Link to="/">
            <ArrowLeft className="h-5 w-5" />
            {t("home")}
          </Link>
        </Button>
        <Button variant="outline" size="lg" onClick={handleSignOut}>
          <LogOut className="h-5 w-5" />
          {t("signOut")}
        </Button>
      </header>

      <main className="container mx-auto px-4 pb-8 space-y-6 max-w-2xl">
        {/* Language Selection Card */}
        <Card className="border-2 border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-accessible-lg text-primary">
              <Globe className="h-7 w-7" />
              {t("language")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={language} onValueChange={(value: "en" | "hi" | "kn") => setLanguage(value)}>
              <SelectTrigger className="w-full h-12 text-base">
                <SelectValue placeholder={t("selectLanguage")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en" className="text-base py-3">
                  🇬🇧 English
                </SelectItem>
                <SelectItem value="hi" className="text-base py-3">
                  🇮🇳 हिन्दी (Hindi)
                </SelectItem>
                <SelectItem value="kn" className="text-base py-3">
                  🇮🇳 ಕನ್ನಡ (Kannada)
                </SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Profile Card */}
        <Card className="border-2 border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-3 text-accessible-lg text-primary">
              <User className="h-7 w-7" />
              {t("myProfile")}
            </CardTitle>
            {!editing ? (
              <Button variant="outline" size="sm" onClick={() => setEditing(true)}>
                <Edit2 className="h-4 w-4" />
                {t("edit")}
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setEditing(false)}>
                  <X className="h-4 w-4" />
                </Button>
                <Button variant="medical" size="sm" onClick={handleSaveProfile}>
                  <Save className="h-4 w-4" />
                  {t("save")}
                </Button>
              </div>
            )}
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">{t("fullName")}</label>
                {editing ? (
                  <Input
                    value={editedProfile.full_name || ""}
                    onChange={(e) => setEditedProfile({ ...editedProfile, full_name: e.target.value })}
                    className="mt-1"
                  />
                ) : (
                  <p className="text-lg">{profile?.full_name || t("notSet")}</p>
                )}
              </div>

              <div>
                <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Phone className="h-4 w-4" /> {t("phone")}
                </label>
                {editing ? (
                  <Input
                    value={editedProfile.phone || ""}
                    onChange={(e) => setEditedProfile({ ...editedProfile, phone: e.target.value })}
                    className="mt-1"
                    placeholder="+91 XXXXX XXXXX"
                  />
                ) : (
                  <p className="text-lg">{profile?.phone || t("notSet")}</p>
                )}
              </div>

              <div>
                <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Heart className="h-4 w-4 text-destructive" /> {t("bloodGroup")}
                </label>
                {editing ? (
                  <Input
                    value={editedProfile.blood_group || ""}
                    onChange={(e) => setEditedProfile({ ...editedProfile, blood_group: e.target.value })}
                    className="mt-1"
                    placeholder="A+, B-, O+, etc."
                  />
                ) : (
                  <p className="text-lg font-semibold text-destructive">{profile?.blood_group || t("notSet")}</p>
                )}
              </div>

              <div>
                <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-amber-500" /> {t("medicalConditions")}
                </label>
                {editing ? (
                  <Input
                    value={editedProfile.medical_conditions || ""}
                    onChange={(e) => setEditedProfile({ ...editedProfile, medical_conditions: e.target.value })}
                    className="mt-1"
                    placeholder="Diabetes, Hypertension, etc."
                  />
                ) : (
                  <p className="text-lg">{profile?.medical_conditions || t("none")}</p>
                )}
              </div>

              <div>
                <label className="text-sm font-medium text-muted-foreground">{t("allergies")}</label>
                {editing ? (
                  <Input
                    value={editedProfile.allergies || ""}
                    onChange={(e) => setEditedProfile({ ...editedProfile, allergies: e.target.value })}
                    className="mt-1"
                    placeholder="Penicillin, Peanuts, etc."
                  />
                ) : (
                  <p className="text-lg">{profile?.allergies || t("none")}</p>
                )}
              </div>

              <div className="pt-4 border-t">
                <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Phone className="h-4 w-4 text-success" /> {t("familyDoctorPhone")}
                </label>
                {editing ? (
                  <Input
                    value={editedProfile.family_doctor_phone || ""}
                    onChange={(e) => setEditedProfile({ ...editedProfile, family_doctor_phone: e.target.value })}
                    className="mt-1"
                    placeholder="+91 XXXXX XXXXX"
                  />
                ) : (
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-lg font-medium text-success">{profile?.family_doctor_phone || t("notSet")}</p>
                    {profile?.family_doctor_phone && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(`tel:${profile.family_doctor_phone}`)}
                      >
                        <Phone className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                )}
                <p className="text-xs text-muted-foreground mt-1">
                  {t("familyDoctorNote")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Family Contacts Card */}
        <Card className="border-2 border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-3 text-accessible-lg text-primary">
              <Users className="h-7 w-7" />
              {t("familyContacts")}
            </CardTitle>
            <Button 
              variant="medical" 
              size="sm" 
              onClick={() => setShowAddContact(!showAddContact)}
            >
              <Plus className="h-4 w-4" />
              {t("add")}
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {showAddContact && (
              <div className="p-4 bg-primary/5 rounded-xl space-y-3">
                <Input
                  placeholder={t("contactName")}
                  value={newContact.name}
                  onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                />
                <Input
                  placeholder={t("relationship")}
                  value={newContact.relationship}
                  onChange={(e) => setNewContact({ ...newContact, relationship: e.target.value })}
                />
                <Input
                  placeholder={t("phone")}
                  value={newContact.phone}
                  onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                />
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={() => setShowAddContact(false)}>
                    {t("cancel")}
                  </Button>
                  <Button variant="medical" className="flex-1" onClick={handleAddContact}>
                    {t("saveContact")}
                  </Button>
                </div>
              </div>
            )}

            {familyContacts.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                {t("noContacts")}
              </p>
            ) : (
              <div className="space-y-3">
                {familyContacts.map((contact) => (
                  <div
                    key={contact.id}
                    className="flex items-center justify-between p-4 bg-card rounded-xl border"
                  >
                    <div>
                      <p className="font-semibold text-lg">{contact.name}</p>
                      <p className="text-sm text-muted-foreground">{contact.relationship}</p>
                      <p className="text-primary font-medium">{contact.phone}</p>
                      {contact.is_primary && (
                        <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">
                          {t("primaryContact")}
                        </span>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => window.open(`tel:${contact.phone}`)}
                      >
                        <Phone className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="icon"
                        onClick={() => handleDeleteContact(contact.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default Profile;
