-- Add family doctor phone field to profiles table
ALTER TABLE public.profiles 
ADD COLUMN family_doctor_phone text;